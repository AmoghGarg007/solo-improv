import { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import socket from "../socket";

function Chat() {

  const location = useLocation();
  const navigate = useNavigate();

  const storedGroup = localStorage.getItem("active_group");
  const autoGroupId = location.state?.groupId || storedGroup || "";

  const [username, setUsername] = useState(
    localStorage.getItem("demo_username") || ""
  );

  const [groupId, setGroupId] = useState(autoGroupId);
  const [joined, setJoined] = useState(false);
  const [text, setText] = useState("");
  const [messages, setMessages] = useState([]);

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  const groupTitle = groupId
    ? groupId.replace(/_\d+$/, "").split("_").join(" + ")
    : "Group Chat";

  /* =========================
     PREVENT PAGE SCROLL ON ENTER
  ========================== */

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Enter") e.preventDefault();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  /* =========================
     AUTO SCROLL
  ========================== */

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  /* =========================
     SOCKET LISTENERS
  ========================== */

  useEffect(() => {

    const handleReceiveMessage = (message) => {
      setMessages(prev => [...prev, message]);
    };

    const handleJoinedGroup = (actualGroupId) => {
      setGroupId(actualGroupId);
      setJoined(true);
      localStorage.setItem("active_group", actualGroupId);
    };

    socket.on("receiveMessage", handleReceiveMessage);
    socket.on("joinedGroup", handleJoinedGroup);

    return () => {
      socket.off("receiveMessage", handleReceiveMessage);
      socket.off("joinedGroup", handleJoinedGroup);
    };

  }, []);

  /* =========================
     JOIN GROUP
  ========================== */

  const handleNameSubmit = () => {
    if (!username || !groupId) return;
    localStorage.setItem("demo_username", username);
    socket.emit("joinGroup", {
      requestedGroup: groupId,
      username,
      clientId: socket.id
    });
  };

  /* =========================
     SEND MESSAGE
  ========================== */

  const sendMessage = () => {
    if (!text.trim() || !joined) return;
    const msg = { groupId, sender: username, text };
    socket.emit("sendMessage", msg);
    setMessages(prev => [...prev, msg]);
    setText("");
    inputRef.current?.focus();
  };

  /* =========================
     NO GROUP STATE
  ========================== */

  if (!groupId) {
    return (
      <div className="chat-page">
        <div className="chat-box glass">
          <h2>No Active Group</h2>
          <button onClick={() => navigate("/find-group")}>
            Go to Find Group
          </button>
        </div>
      </div>
    );
  }

  /* =========================
     UI
  ========================== */

  return (
    <div className="chat-page">
      <div className="chat-box glass">

        <h2>{groupTitle}</h2>

        {!joined ? (
          <>
            <input
              placeholder="Enter your name"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleNameSubmit();
              }}
            />
            <button onClick={handleNameSubmit}>
              Enter Chat
            </button>
          </>
        ) : (
          <>
            <div className="chat-messages">
              {messages.map((msg, index) => (
                <div
                  key={index}
                  className={`chat-message ${
                    msg.sender === username ? "self" : "other"
                  }`}
                >
                  <strong>{msg.sender}:</strong> {msg.text}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <div className="chat-input-row">
              <input
                ref={inputRef}
                placeholder="Type a message..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
              />
              <button onClick={sendMessage}>Send</button>
            </div>
          </>
        )}

      </div>
    </div>
  );
}

export default Chat;
