const express = require("express");
const router = express.Router();

let events = [];
let counter = 1;

router.get("/", (req, res) => {
  res.json(events);
});

router.post("/", (req, res) => {
  const newEvent = {
    id: counter++,
    ...req.body
  };

  events.push(newEvent);
  res.status(201).json(newEvent);
});

router.put("/:id", (req, res) => {
  const id = parseInt(req.params.id);

  const index = events.findIndex(e => e.id === id);
  if (index === -1) {
    return res.status(404).json({ message: "Event not found" });
  }

  events[index] = {
    ...events[index],
    ...req.body
  };

  res.json(events[index]);
});

router.delete("/:id", (req, res) => {
  const id = parseInt(req.params.id);
  events = events.filter(e => e.id !== id);
  res.json({ message: "Deleted" });
});

module.exports = router;